package com.cuerdafloja.client;

import com.cuerdafloja.Net;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;
import java.util.UUID;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CuerdaFlojaClient implements ClientModInitializer {
    static final Identifier KEY_TEX = Identifier.of("cuerdafloja", "textures/gui/key.png");

    static boolean active;
    static int seq, key, window, flash;
    static float stamina;
    static long promptAt, flashAt, lastPacket;
    static String[][] rows = new String[0][];
    public static final Logger LOG = LoggerFactory.getLogger("cuerdafloja");
    public static final Set<UUID> LOGGED = new HashSet<>();
    static boolean frozen;
    static long frozenAt;
    static int announceCode = -1;
    static long announceAt;
    static float offYaw, offPitch;
    static Map<UUID, Integer> balance = new HashMap<>();

    /** Estamina del jugador si está haciendo equilibrio (para animar sus brazos), o null. */
    public static Integer balanceStamina(UUID id) { return balance.get(id); }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(Net.State.ID, (p, ctx) -> {
            long now = System.nanoTime();
            lastPacket = now;
            if (!p.active()) { active = false; rows = new String[0][]; return; }
            if (!active || p.seq() != seq) promptAt = now;
            if (!active) KeyBinding.unpressAll();
            active = true; seq = p.seq(); key = p.key(); window = p.window(); stamina = p.stamina();
            if (p.result() != 0) { flash = p.result(); flashAt = now; }
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Standings.ID, (p, ctx) -> {
            if (p.data().isEmpty()) { rows = new String[0][]; return; }
            String[] parts = p.data().split("\\|");
            rows = new String[parts.length][];
            for (int i = 0; i < parts.length; i++) rows[i] = parts[i].split(":");
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Balance.ID, (p, ctx) -> {
            Map<UUID, Integer> m = new HashMap<>();
            if (!p.data().isEmpty()) {
                for (String e : p.data().split("\\|")) {
                    String[] t = e.split(":");
                    if (t.length != 2) continue;
                    try { m.put(UUID.fromString(t[0]), Integer.parseInt(t[1])); } catch (Exception ignored) {}
                }
            }
            boolean was = balance.isEmpty();
            balance = m;
            if (m.isEmpty()) LOGGED.clear();
            else if (was) LOG.info("Equilibrio recibido del servidor para {} jugador(es)", m.size());
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Freeze.ID, (p, ctx) -> {
            if (p.on() && !frozen) KeyBinding.unpressAll();
            frozen = p.on(); frozenAt = System.nanoTime();
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Announce.ID, (p, ctx) -> {
            announceCode = p.code(); announceAt = System.nanoTime();
            String pling = "minecraft:block.note_block.pling";
            if (p.code() >= 1 && p.code() <= 3) sound(pling, 0.8f, 1f);
            else if (p.code() == 0) {
                sound(pling, 1.8f, 1f);
                sound("minecraft:entity.firework_rocket.blast", 1f, 1f);
                sound("minecraft:entity.player.levelup", 1f, 0.8f);
            } else if (p.code() == 9) {
                sound("minecraft:ui.toast.challenge_complete", 1f, 1f);
                sound("minecraft:entity.firework_rocket.twinkle", 1f, 1f);
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            active = false; frozen = false; announceCode = -1; offYaw = 0; offPitch = 0; balance = new HashMap<>();
        });
        HudRenderCallback.EVENT.register((g, tc) -> { wobble(); renderAnnounce(g); render(g); });
    }

    static void sound(String id, float pitch, float vol) {
        SoundEvent ev = Registries.SOUND_EVENT.get(Identifier.of(id));
        if (ev == null) return;
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev, pitch, vol));
    }

    static boolean isFrozen() { return frozen && System.nanoTime() - frozenAt < 3_000_000_000L; }

    /** Llamado desde el mixin. Devuelve true si hay que bloquear la tecla. */
    public static boolean onKey(int k, int sc, int action) {
        boolean frz = isFrozen();
        if (!active && !frz) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen != null) return false;
        if (k == 256 || (k >= 290 && k <= 301)) return false;               // ESC y F1-F12 siguen funcionando
        if (action == 0) return false;                                       // soltar teclas siempre se permite
        if (active) {
            if (k == 47) return false;                                       // "/" siempre abre el chat de comandos
            if (action == 1 && ((k >= 65 && k <= 90) || (k >= 48 && k <= 57))) {
                if (ClientPlayNetworking.canSend(Net.KeyPress.ID)) ClientPlayNetworking.send(new Net.KeyPress(seq, k));
            }
            return true;                                                     // en juego, el jugador queda quieto
        }
        // Solo congelado (antes de empezar): se bloquea únicamente el movimiento. Chat, inventario, etc. funcionan.
        var o = mc.options;
        return o.forwardKey.matchesKey(k, sc) || o.backKey.matchesKey(k, sc) || o.leftKey.matchesKey(k, sc)
                || o.rightKey.matchesKey(k, sc) || o.jumpKey.matchesKey(k, sc)
                || o.sneakKey.matchesKey(k, sc) || o.sprintKey.matchesKey(k, sc);
    }

    /** Cuenta regresiva 3-2-1-GO y "FIN DEL JUEGO" con imágenes. */
    static void renderAnnounce(DrawContext g) {
        if (announceCode == -1) return;
        double el = (System.nanoTime() - announceAt) / 1e9;
        double dur = announceCode == 9 ? 3.5 : announceCode == 0 ? 1.3 : 1.0;
        if (el > dur) { announceCode = -1; return; }
        String name; int tw, th;
        switch (announceCode) {
            case 3: name = "count_3"; tw = 9; th = 11; break;
            case 2: name = "count_2"; tw = 9; th = 11; break;
            case 1: name = "count_1"; tw = 9; th = 11; break;
            case 0: name = "count_go"; tw = 17; th = 11; break;
            default: name = "fin"; tw = 42; th = 20; break;
        }
        Identifier tex = Identifier.of("cuerdafloja", "textures/gui/" + name + ".png");
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight();
        int k = Math.max(2, Math.min(10, Math.min((int) (w * 0.45 / tw), (int) (h * 0.30 / th))));
        float pop = 1f + 0.35f * (float) Math.max(0, 1 - el / 0.25);
        float alpha = (float) Math.max(0, Math.min(1, (dur - el) / 0.25));
        RenderSystem.enableBlend();
        g.setShaderColor(1f, 1f, 1f, alpha);
        var m = g.getMatrices();
        m.push();
        m.translate(w / 2f, h * 0.30f, 0);
        m.scale(pop, pop, 1f);
        g.drawTexture(tex, -tw * k / 2, -th * k / 2, tw * k, th * k, 0, 0, tw, th, tw, th);
        m.pop();
        g.setShaderColor(1f, 1f, 1f, 1f);
    }

    static float danger() { return active ? Math.max(0f, 1f - stamina / 100f) : 0f; }

    /** La cámara se tambalea más mientras menos estamina tengas. */
    static void wobble() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) { offYaw = 0; offPitch = 0; return; }
        double t = System.nanoTime() / 1e9;
        float amp = danger() * danger();
        float ty = (float) (Math.sin(t * 1.9) * 5.0 + Math.sin(t * 4.7) * 2.0) * amp;
        float tp = (float) (Math.sin(t * 2.3 + 1) * 3.0 + Math.sin(t * 5.9) * 1.2) * amp;
        float ny = offYaw + (ty - offYaw) * 0.25f;
        float np = offPitch + (tp - offPitch) * 0.25f;
        mc.player.changeLookDirection((ny - offYaw) / 0.15, (np - offPitch) / 0.15);
        offYaw = ny; offPitch = np;
    }

    static void render(DrawContext g) {
        if (!active) return;
        long now = System.nanoTime();
        if (now - lastPacket > 3_000_000_000L) { active = false; return; }   // seguridad si el servidor se cae
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight(), cx = w / 2;

        // --- Tecla (textura pixel art + letra) ---
        int s = 68, x = cx - s / 2, y = h / 2 - 95;
        if (now - flashAt < 250_000_000L) {
            if (flash == 1) g.setShaderColor(0.55f, 1f, 0.65f, 1f); else g.setShaderColor(1f, 0.5f, 0.5f, 1f);
        }
        g.drawTexture(KEY_TEX, x, y, s, s, 0, 0, 34, 34, 34, 34);
        g.setShaderColor(1f, 1f, 1f, 1f);
        String label = String.valueOf((char) key);
        var m = g.getMatrices();
        m.push();
        m.translate(cx, y + 16, 0);
        m.scale(3f, 3f, 1f);
        g.drawText(tr, label, -tr.getWidth(label) / 2, 0, 0xFF2B2B2B, false);
        m.pop();

        // --- Tiempo para pulsar ---
        double used = (now - promptAt) / 1e9, win = window / 20.0;
        float frac = (float) Math.max(0, 1 - used / win);
        g.fill(x, y + s + 6, x + s, y + s + 12, 0xFF333333);
        g.fill(x, y + s + 6, x + (int) (s * frac), y + s + 12, 0xFFE0A21B);

        // --- Barra de estamina ---
        int bw = 180, bx = cx - bw / 2, by = h / 2 + 10;
        int col = stamina > 55 ? 0xFF2E9E5B : stamina > 25 ? 0xFFE0A21B : 0xFFD64545;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 11, 0xFF111111);
        g.fill(bx, by, bx + bw, by + 10, 0xFF3A3A3A);
        g.fill(bx, by, bx + (int) (bw * stamina / 100f), by + 10, col);
        g.drawCenteredTextWithShadow(tr, "ESTAMINA " + (int) stamina, cx, by + 14, 0xFFFFFFFF);

        // --- Equilibrio: el puntero se mueve más cuando te quedas sin estamina ---
        double t = now / 1e9;
        int my = by + 30;
        float d = danger();
        int px = cx + (int) (Math.sin(t * 3.1) * (6 + d * 62) + Math.sin(t * 7.3) * d * 10);
        g.fill(cx - 70, my + 4, cx + 70, my + 6, 0xFF8A8A8A);
        g.fill(cx - 1, my + 1, cx + 1, my + 9, 0xFFFFFFFF);
        g.fill(px - 3, my, px + 3, my + 10, col);
        g.drawCenteredTextWithShadow(tr, "EQUILIBRIO", cx, my + 14, 0xFFBBBBBB);

        // --- Ranking: los más cerca de caer primero ---
        int rx = w - 112, ry = 8;
        g.drawTextWithShadow(tr, "⚠ PELIGRO", rx, ry, 0xFFFFD34D);
        for (int i = 0; i < rows.length && i < 10; i++) {
            if (rows[i].length < 2) continue;
            int v = Integer.parseInt(rows[i][1].trim());
            int c = v > 55 ? 0xFF7CE0A3 : v > 25 ? 0xFFF2C94C : 0xFFFF6B6B;
            g.drawTextWithShadow(tr, rows[i][0] + " " + v, rx, ry + 12 + i * 10, c);
        }
    }
}
