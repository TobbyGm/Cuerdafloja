package com.cuerdafloja.client;

import com.cuerdafloja.Net;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public class CuerdaFlojaClient implements ClientModInitializer {
    static boolean active;
    static int seq, key, window, flash;
    static float stamina;
    static long promptAt, flashAt, lastPacket;
    static String[][] rows = new String[0][];

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(Net.State.ID, (p, ctx) -> {
            long now = System.nanoTime();
            lastPacket = now;
            if (!p.active()) { active = false; rows = new String[0][]; return; }
            if (!active || p.seq() != seq) promptAt = now;
            active = true; seq = p.seq(); key = p.key(); window = p.window(); stamina = p.stamina();
            if (p.result() != 0) { flash = p.result(); flashAt = now; }
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Standings.ID, (p, ctx) -> {
            if (p.data().isEmpty()) { rows = new String[0][]; return; }
            String[] parts = p.data().split("\\|");
            rows = new String[parts.length][];
            for (int i = 0; i < parts.length; i++) rows[i] = parts[i].split(":");
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> active = false);
        HudRenderCallback.EVENT.register((g, tc) -> render(g));
    }

    /** Llamado desde el mixin. Devuelve true si hay que bloquear la tecla. */
    public static boolean onKey(int k, int action) {
        if (!active) return false;
        if (MinecraftClient.getInstance().currentScreen != null) return false;
        if (k == 256 || (k >= 290 && k <= 301)) return false;               // ESC y F1-F12 siguen funcionando
        if (action == 1 && ((k >= 65 && k <= 90) || (k >= 48 && k <= 57))) {
            if (ClientPlayNetworking.canSend(Net.KeyPress.ID)) ClientPlayNetworking.send(new Net.KeyPress(seq, k));
        }
        return true;                                                         // el jugador queda quieto en la cuerda
    }

    static void render(DrawContext g) {
        if (!active) return;
        long now = System.nanoTime();
        if (now - lastPacket > 3_000_000_000L) { active = false; return; }   // seguridad si el servidor se cae
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight(), cx = w / 2;

        // --- Tecla (cuadrado) ---
        int s = 52, x = cx - s / 2, y = h / 2 - 75;
        int face = 0xFFF2EDE3;
        if (now - flashAt < 250_000_000L) face = flash == 1 ? 0xFF4CD98A : 0xFFE86A6A;
        g.fill(x - 2, y - 2, x + s + 2, y + s + 6, 0xFF111111);
        g.fill(x, y + 4, x + s, y + s + 4, 0xFF8A8478);
        g.fill(x, y, x + s, y + s, face);
        String label = String.valueOf((char) key);
        var m = g.getMatrices();
        m.push();
        m.translate(cx, y + 12, 0);
        m.scale(3f, 3f, 1f);
        g.drawText(tr, label, -tr.getWidth(label) / 2, 0, 0xFF1A1A1A, false);
        m.pop();

        // --- Tiempo para pulsar ---
        double used = (now - promptAt) / 1e9, win = window / 20.0;
        float frac = (float) Math.max(0, 1 - used / win);
        g.fill(x, y + s + 10, x + s, y + s + 16, 0xFF333333);
        g.fill(x, y + s + 10, x + (int) (s * frac), y + s + 16, 0xFFE0A21B);

        // --- Barra de estamina ---
        int bw = 180, bx = cx - bw / 2, by = h / 2 + 10;
        int col = stamina > 55 ? 0xFF2E9E5B : stamina > 25 ? 0xFFE0A21B : 0xFFD64545;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 11, 0xFF111111);
        g.fill(bx, by, bx + bw, by + 10, 0xFF3A3A3A);
        g.fill(bx, by, bx + (int) (bw * stamina / 100f), by + 10, col);
        g.drawCenteredTextWithShadow(tr, "ESTAMINA " + (int) stamina, cx, by + 14, 0xFFFFFFFF);

        // --- Ranking: los más cerca de caer primero ---
        int rx = w - 112, ry = 8;
        g.drawTextWithShadow(tr, "⚠ PELIGRO", rx, ry, 0xFFFFD34D);
        for (int i = 0; i < rows.length && i < 10; i++) {
            if (rows[i].length < 2) continue;
            int v = Integer.parseInt(rows[i][1].trim());
            int c = v > 55 ? 0xFF7CE0A3 : v > 25 ? 0xFFF2C94C : 0xFFFF6B6B;
            g.drawTextWithShadow(tr, rows[i][0] + " " + v, rx, ry + 12 + i * 10, c);
        }
    }
}
