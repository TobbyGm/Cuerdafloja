package com.cuerdafloja.client;

import com.cuerdafloja.Net;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.util.Identifier;

public class CuerdaFlojaClient implements ClientModInitializer {
    static final Identifier KEY_TEX = Identifier.of("cuerdafloja", "textures/gui/key.png");

    static boolean active;
    static int seq, key, window, flash;
    static float stamina;
    static long promptAt, flashAt, lastPacket;
    static String[][] rows = new String[0][];
    static float offYaw, offPitch;
    static Map<UUID, Integer> balance = new HashMap<>();

    /** Estamina del jugador si está haciendo equilibrio (para animar sus brazos), o null. */
    public static Integer balanceStamina(UUID id) { return balance.get(id); }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(Net.State.ID, (p, ctx) -> {
            long now = System.nanoTime();
            lastPacket = now;
            if (!p.active()) { active = false; rows = new String[0][]; return; }
            if (!active || p.seq() != seq) promptAt = now;
            active = true; seq = p.seq(); key = p.key(); window = p.window(); stamina = p.stamina();
            if (p.result() != 0) { flash = p.result(); flashAt = now; }
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Standings.ID, (p, ctx) -> {
            if (p.data().isEmpty()) { rows = new String[0][]; return; }
            String[] parts = p.data().split("\\|");
            rows = new String[parts.length][];
            for (int i = 0; i < parts.length; i++) rows[i] = parts[i].split(":");
        });
        ClientPlayNetworking.registerGlobalReceiver(Net.Balance.ID, (p, ctx) -> {
            Map<UUID, Integer> m = new HashMap<>();
            if (!p.data().isEmpty()) {
                for (String e : p.data().split("\\|")) {
                    String[] t = e.split(":");
                    if (t.length != 2) continue;
                    try { m.put(UUID.fromString(t[0]), Integer.parseInt(t[1])); } catch (Exception ignored) {}
                }
            }
            balance = m;
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> { active = false; offYaw = 0; offPitch = 0; balance = new HashMap<>(); });
        HudRenderCallback.EVENT.register((g, tc) -> { wobble(); render(g); });
    }

    /** Llamado desde el mixin. Devuelve true si hay que bloquear la tecla. */
    public static boolean onKey(int k, int action) {
        if (!active) return false;
        if (MinecraftClient.getInstance().currentScreen != null) return false;
        if (k == 256 || (k >= 290 && k <= 301)) return false;               // ESC y F1-F12 siguen funcionando
        if (action == 1 && ((k >= 65 && k <= 90) || (k >= 48 && k <= 57))) {
            if (ClientPlayNetworking.canSend(Net.KeyPress.ID)) ClientPlayNetworking.send(new Net.KeyPress(seq, k));
        }
        return true;                                                         // el jugador queda quieto en la cuerda
    }

    static float danger() { return active ? Math.max(0f, 1f - stamina / 100f) : 0f; }

    /** La cámara se tambalea más mientras menos estamina tengas. */
    static void wobble() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) { offYaw = 0; offPitch = 0; return; }
        double t = System.nanoTime() / 1e9;
        float amp = danger() * danger();
        float ty = (float) (Math.sin(t * 1.9) * 5.0 + Math.sin(t * 4.7) * 2.0) * amp;
        float tp = (float) (Math.sin(t * 2.3 + 1) * 3.0 + Math.sin(t * 5.9) * 1.2) * amp;
        float ny = offYaw + (ty - offYaw) * 0.25f;
        float np = offPitch + (tp - offPitch) * 0.25f;
        mc.player.changeLookDirection((ny - offYaw) / 0.15, (np - offPitch) / 0.15);
        offYaw = ny; offPitch = np;
    }

    static void render(DrawContext g) {
        if (!active) return;
        long now = System.nanoTime();
        if (now - lastPacket > 3_000_000_000L) { active = false; return; }   // seguridad si el servidor se cae
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int w = g.getScaledWindowWidth(), h = g.getScaledWindowHeight(), cx = w / 2;

        // --- Tecla (textura pixel art + letra) ---
        int s = 68, x = cx - s / 2, y = h / 2 - 95;
        if (now - flashAt < 250_000_000L) {
            if (flash == 1) g.setShaderColor(0.55f, 1f, 0.65f, 1f); else g.setShaderColor(1f, 0.5f, 0.5f, 1f);
        }
        g.drawTexture(KEY_TEX, x, y, s, s, 0, 0, 34, 34, 34, 34);
        g.setShaderColor(1f, 1f, 1f, 1f);
        String label = String.valueOf((char) key);
        var m = g.getMatrices();
        m.push();
        m.translate(cx, y + 16, 0);
        m.scale(3f, 3f, 1f);
        g.drawText(tr, label, -tr.getWidth(label) / 2, 0, 0xFF2B2B2B, false);
        m.pop();

        // --- Tiempo para pulsar ---
        double used = (now - promptAt) / 1e9, win = window / 20.0;
        float frac = (float) Math.max(0, 1 - used / win);
        g.fill(x, y + s + 6, x + s, y + s + 12, 0xFF333333);
        g.fill(x, y + s + 6, x + (int) (s * frac), y + s + 12, 0xFFE0A21B);

        // --- Barra de estamina ---
        int bw = 180, bx = cx - bw / 2, by = h / 2 + 10;
        int col = stamina > 55 ? 0xFF2E9E5B : stamina > 25 ? 0xFFE0A21B : 0xFFD64545;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 11, 0xFF111111);
        g.fill(bx, by, bx + bw, by + 10, 0xFF3A3A3A);
        g.fill(bx, by, bx + (int) (bw * stamina / 100f), by + 10, col);
        g.drawCenteredTextWithShadow(tr, "ESTAMINA " + (int) stamina, cx, by + 14, 0xFFFFFFFF);

        // --- Equilibrio: el puntero se mueve más cuando te quedas sin estamina ---
        double t = now / 1e9;
        int my = by + 30;
        float d = danger();
        int px = cx + (int) (Math.sin(t * 3.1) * (6 + d * 62) + Math.sin(t * 7.3) * d * 10);
        g.fill(cx - 70, my + 4, cx + 70, my + 6, 0xFF8A8A8A);
        g.fill(cx - 1, my + 1, cx + 1, my + 9, 0xFFFFFFFF);
        g.fill(px - 3, my, px + 3, my + 10, col);
        g.drawCenteredTextWithShadow(tr, "EQUILIBRIO", cx, my + 14, 0xFFBBBBBB);

        // --- Ranking: los más cerca de caer primero ---
        int rx = w - 112, ry = 8;
        g.drawTextWithShadow(tr, "⚠ PELIGRO", rx, ry, 0xFFFFD34D);
        for (int i = 0; i < rows.length && i < 10; i++) {
            if (rows[i].length < 2) continue;
            int v = Integer.parseInt(rows[i][1].trim());
            int c = v > 55 ? 0xFF7CE0A3 : v > 25 ? 0xFFF2C94C : 0xFFFF6B6B;
            g.drawTextWithShadow(tr, rows[i][0] + " " + v, rx, ry + 12 + i * 10, c);
        }
    }
}
