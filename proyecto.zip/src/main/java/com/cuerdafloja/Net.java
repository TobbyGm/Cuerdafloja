package com.cuerdafloja;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Paquetes entre cliente y servidor. */
public final class Net {
    private Net() {}

    /** Cliente -> servidor: tecla pulsada (código GLFW; A-Z = 65-90, 0-9 = 48-57). */
    public record KeyPress(int seq, int key) implements CustomPayload {
        public static final CustomPayload.Id<KeyPress> ID = new CustomPayload.Id<>(Identifier.of("cuerdafloja", "key_press"));
        public static final PacketCodec<RegistryByteBuf, KeyPress> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, KeyPress::seq,
                PacketCodecs.VAR_INT, KeyPress::key,
                KeyPress::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Servidor -> cliente: tecla actual, tiempo (ticks), estamina. result: 0 nada, 1 acierto, 2 fallo. */
    public record State(boolean active, int seq, int key, int window, float stamina, int result) implements CustomPayload {
        public static final CustomPayload.Id<State> ID = new CustomPayload.Id<>(Identifier.of("cuerdafloja", "state"));
        public static final PacketCodec<RegistryByteBuf, State> CODEC = PacketCodec.tuple(
                PacketCodecs.BOOL, State::active,
                PacketCodecs.VAR_INT, State::seq,
                PacketCodecs.VAR_INT, State::key,
                PacketCodecs.VAR_INT, State::window,
                PacketCodecs.FLOAT, State::stamina,
                PacketCodecs.VAR_INT, State::result,
                State::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Servidor -> cliente: jugadores que están en equilibrio "uuid:estamina|uuid:estamina". */
    public record Balance(String data) implements CustomPayload {
        public static final CustomPayload.Id<Balance> ID = new CustomPayload.Id<>(Identifier.of("cuerdafloja", "balance"));
        public static final PacketCodec<RegistryByteBuf, Balance> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, Balance::data,
                Balance::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Servidor -> cliente: ranking "nombre:estamina|nombre:estamina" (menor estamina primero). */
    public record Standings(String data) implements CustomPayload {
        public static final CustomPayload.Id<Standings> ID = new CustomPayload.Id<>(Identifier.of("cuerdafloja", "standings"));
        public static final PacketCodec<RegistryByteBuf, Standings> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, Standings::data,
                Standings::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }
}
