package com.cuerdafloja;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.function.BiConsumer;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class Commands {
    private Commands() {}

    static void msg(CommandContext<ServerCommandSource> c, String s) {
        c.getSource().sendFeedback(() -> Text.literal(s), false);
    }

    static LiteralArgumentBuilder<ServerCommandSource> dbl(String name, double min, double max, BiConsumer<Game, Double> set) {
        return literal(name).then(argument("v", DoubleArgumentType.doubleArg(min, max)).executes(c -> {
            double v = DoubleArgumentType.getDouble(c, "v");
            set.accept(CuerdaFloja.GAME, v);
            msg(c, name + " = " + v);
            return 1;
        }));
    }

    static int ropeCmd(CommandContext<ServerCommandSource> c, boolean build) throws CommandSyntaxException {
        BlockPos a = BlockPosArgumentType.getBlockPos(c, "desde").toImmutable();
        BlockPos b = BlockPosArgumentType.getBlockPos(c, "hasta").toImmutable();
        String err = Ropes.validate(a, b);
        if (err != null) { msg(c, err); return 0; }
        ServerWorld w = c.getSource().getWorld();
        if (build) Ropes.build(w, a, b);
        Ropes.LIST.add(new Ropes.Rope(w.getRegistryKey(), a, b));
        Ropes.save();
        msg(c, (build ? "Cuerda construida y registrada: " : "Cuerda registrada: ") + Ropes.describe(Ropes.LIST.size() - 1, Ropes.LIST.get(Ropes.LIST.size() - 1)));
        return 1;
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        Game g = CuerdaFloja.GAME;
        d.register(literal("cuerdafloja").requires(s -> s.hasPermissionLevel(2))
            .then(literal("add").then(argument("jugadores", EntityArgumentType.players()).executes(c -> {
                int n = 0;
                for (ServerPlayerEntity p : EntityArgumentType.getPlayers(c, "jugadores")) if (g.add(p)) n++;
                msg(c, n + " jugador(es) añadidos. " + g.list());
                return n;
            })))
            .then(literal("remove").then(argument("jugadores", EntityArgumentType.players()).executes(c -> {
                int n = 0;
                for (ServerPlayerEntity p : EntityArgumentType.getPlayers(c, "jugadores")) if (g.remove(p)) n++;
                msg(c, n + " jugador(es) quitados.");
                return n;
            })))
            .then(literal("tp").executes(c -> {
                if (Ropes.LIST.isEmpty()) { msg(c, "Primero crea una cuerda: /cuerdafloja rope build <desde> <hasta>"); return 0; }
                var srv = c.getSource().getServer();
                int n = Ropes.tp(srv, g.online(srv), g.perRope);
                if (n < 0) {
                    msg(c, "Faltan cuerdas: necesitas " + (-n) + " para " + g.online(srv).size() + " jugadores (máx. "
                            + g.perRope + " por cuerda) y hay " + Ropes.LIST.size() + ". Crea más o sube: /cuerdafloja config perrope <n>");
                    return 0;
                }
                g.freezeAll(g.online(srv));
                msg(c, n + " jugador(es) puestos en la cuerda y congelados hasta que empiece el juego.");
                return n;
            }))
            .then(literal("pose").then(argument("jugadores", EntityArgumentType.players())
                .then(argument("on", BoolArgumentType.bool()).executes(c -> {
                    boolean on = BoolArgumentType.getBool(c, "on");
                    g.pose(EntityArgumentType.getPlayers(c, "jugadores"), on);
                    msg(c, "Pose de equilibrio de prueba: " + on);
                    return 1;
                }))))
            .then(literal("unfreeze").executes(c -> { g.unfreezeAll(); msg(c, "Jugadores liberados."); return 1; }))
            .then(literal("rope")
                .then(literal("build").then(argument("desde", BlockPosArgumentType.blockPos())
                    .then(argument("hasta", BlockPosArgumentType.blockPos()).executes(c -> ropeCmd(c, true)))))
                .then(literal("add").then(argument("desde", BlockPosArgumentType.blockPos())
                    .then(argument("hasta", BlockPosArgumentType.blockPos()).executes(c -> ropeCmd(c, false)))))
                .then(literal("list").executes(c -> {
                    if (Ropes.LIST.isEmpty()) msg(c, "No hay cuerdas.");
                    for (int i = 0; i < Ropes.LIST.size(); i++) msg(c, Ropes.describe(i, Ropes.LIST.get(i)));
                    return Ropes.LIST.size();
                }))
                .then(literal("remove").then(argument("n", IntegerArgumentType.integer(1)).executes(c -> {
                    int n = IntegerArgumentType.getInteger(c, "n");
                    if (n > Ropes.LIST.size()) { msg(c, "No existe esa cuerda."); return 0; }
                    Ropes.LIST.remove(n - 1); Ropes.save();
                    msg(c, "Cuerda " + n + " quitada de la lista (los bloques no se borran).");
                    return 1;
                })))
                .then(literal("clear").executes(c -> { Ropes.LIST.clear(); Ropes.save(); msg(c, "Cuerdas borradas de la lista."); return 1; })))
            .then(literal("list").executes(c -> { msg(c, g.list()); return 1; }))
            .then(literal("start").executes(c -> {
                String err = g.start(c.getSource().getServer());
                if (err != null) msg(c, err);
                return err == null ? 1 : 0;
            }))
            .then(literal("stop").executes(c -> { msg(c, g.stop() ? "Detenida." : "No hay partida."); return 1; }))
            .then(literal("survivors").then(argument("n", IntegerArgumentType.integer(0)).executes(c -> {
                g.survivors = IntegerArgumentType.getInteger(c, "n");
                msg(c, "Sobrevivientes = " + g.survivors);
                return 1;
            })))
            .then(literal("config")
                .then(dbl("startstamina", 1, 100, (x, v) -> x.startStamina = v))
                .then(dbl("speed", 0.1, 5, (x, v) -> x.drainMult = v))
                .then(dbl("drain", 0, 100, (x, v) -> x.baseDrain = v))
                .then(dbl("ramp", 0, 10, (x, v) -> x.drainRamp = v))
                .then(dbl("window", 0.2, 10, (x, v) -> x.windowSec = v))
                .then(dbl("minwindow", 0.2, 10, (x, v) -> x.minWindowSec = v))
                .then(dbl("hitgain", 0, 100, (x, v) -> x.hitGain = v))
                .then(dbl("hitbonus", 0, 100, (x, v) -> x.hitBonus = v))
                .then(dbl("wrongpenalty", 0, 100, (x, v) -> x.wrongPenalty = v))
                .then(dbl("latepenalty", 0, 100, (x, v) -> x.latePenalty = v))
                .then(literal("perrope").then(argument("n", IntegerArgumentType.integer(1, 10)).executes(c -> {
                    g.perRope = IntegerArgumentType.getInteger(c, "n");
                    msg(c, "Máximo por cuerda = " + g.perRope);
                    return 1;
                })))
                .then(literal("kill").then(argument("v", BoolArgumentType.bool()).executes(c -> {
                    g.killOnFall = BoolArgumentType.getBool(c, "v");
                    msg(c, "Morir al caer = " + g.killOnFall);
                    return 1;
                })))
                .then(dbl("falltime", 0, 60, (x, v) -> x.killAfterSec = v))
                .then(literal("keys").then(argument("v", StringArgumentType.word()).executes(c -> {
                    boolean ok = g.setKeys(StringArgumentType.getString(c, "v"));
                    msg(c, ok ? "Teclas = " + g.keys : "Pon al menos 2 teclas distintas (A-Z, 0-9).");
                    return ok ? 1 : 0;
                })))));
    }
}
