package com.cuerdafloja;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.util.function.BiConsumer;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class Commands {
    private Commands() {}

    static void msg(CommandContext<ServerCommandSource> c, String s) {
        c.getSource().sendFeedback(() -> Text.literal(s), false);
    }

    static LiteralArgumentBuilder<ServerCommandSource> dbl(String name, double min, double max, BiConsumer<Game, Double> set) {
        return literal(name).then(argument("v", DoubleArgumentType.doubleArg(min, max)).executes(c -> {
            double v = DoubleArgumentType.getDouble(c, "v");
            set.accept(CuerdaFloja.GAME, v);
            msg(c, name + " = " + v);
            return 1;
        }));
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        Game g = CuerdaFloja.GAME;
        d.register(literal("cuerdafloja").requires(s -> s.hasPermissionLevel(2))
            .then(literal("add").then(argument("jugadores", EntityArgumentType.players()).executes(c -> {
                int n = 0;
                for (ServerPlayerEntity p : EntityArgumentType.getPlayers(c, "jugadores")) if (g.add(p)) n++;
                msg(c, n + " jugador(es) añadidos. " + g.list());
                return n;
            })))
            .then(literal("remove").then(argument("jugadores", EntityArgumentType.players()).executes(c -> {
                int n = 0;
                for (ServerPlayerEntity p : EntityArgumentType.getPlayers(c, "jugadores")) if (g.remove(p)) n++;
                msg(c, n + " jugador(es) quitados.");
                return n;
            })))
            .then(literal("list").executes(c -> { msg(c, g.list()); return 1; }))
            .then(literal("start").executes(c -> {
                String err = g.start(c.getSource().getServer());
                if (err != null) msg(c, err);
                return err == null ? 1 : 0;
            }))
            .then(literal("stop").executes(c -> { msg(c, g.stop() ? "Detenida." : "No hay partida."); return 1; }))
            .then(literal("survivors").then(argument("n", IntegerArgumentType.integer(0)).executes(c -> {
                g.survivors = IntegerArgumentType.getInteger(c, "n");
                msg(c, "Sobrevivientes = " + g.survivors);
                return 1;
            })))
            .then(literal("config")
                .then(dbl("startstamina", 1, 100, (x, v) -> x.startStamina = v))
                .then(dbl("drain", 0, 100, (x, v) -> x.baseDrain = v))
                .then(dbl("ramp", 0, 10, (x, v) -> x.drainRamp = v))
                .then(dbl("window", 0.2, 10, (x, v) -> x.windowSec = v))
                .then(dbl("minwindow", 0.2, 10, (x, v) -> x.minWindowSec = v))
                .then(dbl("hitgain", 0, 100, (x, v) -> x.hitGain = v))
                .then(dbl("hitbonus", 0, 100, (x, v) -> x.hitBonus = v))
                .then(dbl("wrongpenalty", 0, 100, (x, v) -> x.wrongPenalty = v))
                .then(dbl("latepenalty", 0, 100, (x, v) -> x.latePenalty = v))
                .then(literal("keys").then(argument("v", StringArgumentType.word()).executes(c -> {
                    boolean ok = g.setKeys(StringArgumentType.getString(c, "v"));
                    msg(c, ok ? "Teclas = " + g.keys : "Pon al menos 2 teclas distintas (A-Z, 0-9).");
                    return ok ? 1 : 0;
                })))));
    }
}
