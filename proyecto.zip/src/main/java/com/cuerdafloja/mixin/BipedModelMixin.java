package com.cuerdafloja.mixin;

import com.cuerdafloja.client.CuerdaFlojaClient;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Pose de equilibrio: brazos en T moviéndose. Entre más baja la estamina, más se agitan. */
@Mixin(BipedEntityModel.class)
public class BipedModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void cuerdafloja$balance(LivingEntity entity, float f, float g, float h, float i, float j, CallbackInfo ci) {
        if (!(entity instanceof PlayerEntity)) return;
        Integer st = CuerdaFlojaClient.balanceStamina(entity.getUuid());
        if (st == null) return;
        BipedEntityModel<?> m = (BipedEntityModel<?>) (Object) this;
        float danger = 1f - Math.max(0, Math.min(100, st)) / 100f;
        float amp = 0.12f + 0.55f * danger;
        float a = h * (0.22f + 0.25f * danger) + (entity.getUuid().hashCode() & 255) / 40f;
        m.rightArm.pitch = (float) Math.sin(a * 0.7f) * 0.15f;
        m.leftArm.pitch = (float) Math.sin(a * 0.7f + 1.3f) * 0.15f;
        m.rightArm.yaw = 0f;
        m.leftArm.yaw = 0f;
        m.rightArm.roll = 1.45f + (float) Math.sin(a) * amp;
        m.leftArm.roll = -(1.45f + (float) Math.sin(a + 2.2f) * amp);
        if (m instanceof PlayerEntityModel<?> pm) {
            pm.rightSleeve.copyTransform(m.rightArm);
            pm.leftSleeve.copyTransform(m.leftArm);
        }
    }
}
