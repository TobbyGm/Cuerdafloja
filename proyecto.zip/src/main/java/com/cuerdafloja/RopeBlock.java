package com.cuerdafloja;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;

/** Bloque de cuerda: fino (4x4 píxeles) y se puede colocar en X, Y o Z. */
public class RopeBlock extends PillarBlock {
    private static final VoxelShape SHAPE_X = Block.createCuboidShape(0, 6, 6, 16, 10, 10);
    private static final VoxelShape SHAPE_Z = Block.createCuboidShape(6, 6, 0, 10, 10, 16);
    private static final VoxelShape SHAPE_Y = Block.createCuboidShape(6, 0, 6, 10, 16, 10);

    public RopeBlock(Settings settings) { super(settings); }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        switch (state.get(AXIS)) {
            case X: return SHAPE_X;
            case Z: return SHAPE_Z;
            default: return SHAPE_Y;
        }
    }
}
