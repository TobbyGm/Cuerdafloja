package com.cuerdafloja;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public class CuerdaFloja implements ModInitializer {
    public static final Game GAME = new Game();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(Net.KeyPress.ID, Net.KeyPress.CODEC);
        PayloadTypeRegistry.playS2C().register(Net.State.ID, Net.State.CODEC);
        PayloadTypeRegistry.playS2C().register(Net.Standings.ID, Net.Standings.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Net.KeyPress.ID,
                (payload, ctx) -> GAME.onKey(ctx.player(), payload.seq(), payload.key()));

        ServerTickEvents.END_SERVER_TICK.register(GAME::tick);
        CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> Commands.register(dispatcher));
    }
}
