package com.cuerdafloja;

import java.util.*;
import java.util.stream.Collectors;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class Game {
    static class P {
        UUID id; String name; double stamina;
        int seq, key, window; long promptTick, deadline;
    }

    final Map<UUID, P> roster = new LinkedHashMap<>();
    final Random rnd = new Random();
    MinecraftServer server;
    public boolean running;
    long tick;

    // ---- Configuración (editable con /cuerdafloja config ...) ----
    public int survivors = 4;            // cuántos quedan vivos para terminar
    public double startStamina = 60;     // estamina inicial (0-100)
    public double baseDrain = 5;         // pérdida por segundo al inicio
    public double drainRamp = 0.35;      // cuánto aumenta la pérdida cada segundo
    public double windowSec = 1.7;       // segundos para pulsar al inicio
    public double minWindowSec = 0.65;   // mínimo de segundos para pulsar
    public double hitGain = 7;           // estamina base por acierto
    public double hitBonus = 9;          // extra por acertar rápido
    public double wrongPenalty = 12;     // castigo por tecla equivocada
    public double latePenalty = 14;      // castigo por tardar
    public String keys = "ASDFQWERZXCVJKL";

    public boolean setKeys(String s) {
        String k = s.toUpperCase().replaceAll("[^A-Z0-9]", "");
        k = k.chars().distinct().collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
        if (k.length() < 2) return false;
        keys = k;
        return true;
    }

    // ---- Jugadores ----
    public boolean add(ServerPlayerEntity sp) {
        if (running) return false;
        P p = new P();
        p.id = sp.getUuid(); p.name = sp.getName().getString(); p.stamina = startStamina;
        roster.put(p.id, p);
        return true;
    }

    public boolean remove(ServerPlayerEntity sp) {
        P p = roster.remove(sp.getUuid());
        if (p == null) return false;
        if (running) { sendOff(sp); if (roster.size() <= survivors) finish(); }
        return true;
    }

    public String list() {
        if (roster.isEmpty()) return "No hay jugadores en la cuerda floja.";
        return "Jugadores (" + roster.size() + "): " +
                roster.values().stream().map(p -> p.name).collect(Collectors.joining(", "));
    }

    // ---- Control de partida ----
    public String start(MinecraftServer s) {
        if (running) return "Ya hay una partida en marcha.";
        if (roster.size() <= survivors)
            return "Necesitas más jugadores (" + roster.size() + ") que sobrevivientes (" + survivors + ").";
        server = s; running = true; tick = 0;
        for (P p : roster.values()) { p.stamina = startStamina; prompt(p, 0); }
        broadcast("¡CUERDA FLOJA! Quedan vivos " + survivors + ". ¡Pulsa las teclas!", Formatting.GOLD);
        return null;
    }

    public boolean stop() {
        if (!running) return false;
        for (P p : roster.values()) { ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id); if (sp != null) sendOff(sp); }
        running = false; roster.clear();
        broadcast("Cuerda floja cancelada.", Formatting.GRAY);
        return true;
    }

    void finish() {
        String names = roster.values().stream().map(p -> p.name).collect(Collectors.joining(", "));
        for (P p : roster.values()) { ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id); if (sp != null) sendOff(sp); }
        broadcast("🏆 Sobrevivieron: " + names, Formatting.GREEN);
        running = false; roster.clear();
    }

    // ---- Lógica por tick ----
    public void tick(MinecraftServer s) {
        if (!running) return;
        tick++;
        double el = tick / 20.0;
        double rate = baseDrain + drainRamp * el;

        for (P p : new ArrayList<>(roster.values())) {
            if (s.getPlayerManager().getPlayer(p.id) == null) { p.stamina = -1000; continue; }
            p.stamina -= rate / 20.0;
            if (tick > p.deadline) { p.stamina -= latePenalty; prompt(p, 2); }
        }

        List<P> dead = roster.values().stream().filter(p -> p.stamina <= 0)
                .sorted(Comparator.comparingDouble(p -> p.stamina)).collect(Collectors.toList());
        for (P p : dead) {
            if (roster.size() <= survivors) { p.stamina = 1; continue; }   // se salva por poco
            eliminate(p);
        }
        if (roster.size() <= survivors) { finish(); return; }

        if (tick % 2 == 0) syncAll();
    }

    public void onKey(ServerPlayerEntity sp, int seq, int key) {
        if (!running) return;
        P p = roster.get(sp.getUuid());
        if (p == null || seq != p.seq) return;
        if (!((key >= 65 && key <= 90) || (key >= 48 && key <= 57))) return;
        if (key == p.key) {
            double frac = Math.max(0, 1 - (double) (tick - p.promptTick) / p.window);
            p.stamina = Math.min(100, p.stamina + hitGain + hitBonus * frac);
            prompt(p, 1);
        } else {
            p.stamina -= wrongPenalty;
            prompt(p, 2);
        }
    }

    // ---- Auxiliares ----
    void prompt(P p, int result) {
        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
        if (sp == null) return;
        int prev = p.key;
        do { p.key = keys.charAt(rnd.nextInt(keys.length())); } while (p.key == prev);
        double el = tick / 20.0;
        p.seq++;
        p.window = (int) (Math.max(minWindowSec, windowSec - 0.025 * el) * 20);
        p.promptTick = tick; p.deadline = tick + p.window;
        send(sp, p, result);
    }

    void send(ServerPlayerEntity sp, P p, int result) {
        float st = (float) Math.max(0, Math.min(100, p.stamina));
        ServerPlayNetworking.send(sp, new Net.State(true, p.seq, p.key, p.window, st, result));
    }

    void sendOff(ServerPlayerEntity sp) {
        ServerPlayNetworking.send(sp, new Net.State(false, 0, 0, 0, 0f, 0));
        ServerPlayNetworking.send(sp, new Net.Standings(""));
    }

    void syncAll() {
        String st = roster.values().stream().sorted(Comparator.comparingDouble(p -> p.stamina)).limit(12)
                .map(p -> p.name + ":" + (int) Math.max(0, p.stamina)).collect(Collectors.joining("|"));
        for (P p : roster.values()) {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
            if (sp == null) continue;
            send(sp, p, 0);
            ServerPlayNetworking.send(sp, new Net.Standings(st));
        }
    }

    void eliminate(P p) {
        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
        roster.remove(p.id);
        if (sp != null) { sendOff(sp); sp.kill(); }
        broadcast("☠ " + p.name + " se cayó de la cuerda. Quedan " + roster.size() + ".", Formatting.RED);
    }

    void broadcast(String msg, Formatting f) {
        server.getPlayerManager().broadcast(Text.literal(msg).formatted(f), false);
    }
}
