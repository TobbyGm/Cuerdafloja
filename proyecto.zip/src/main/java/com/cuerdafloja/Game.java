package com.cuerdafloja;

import java.util.*;
import java.util.stream.Collectors;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

public class Game {
    static class P {
        UUID id; String name; double stamina;
        int seq, key, window; long promptTick, deadline;
    }

    final Map<UUID, P> roster = new LinkedHashMap<>();
    final Random rnd = new Random();
    MinecraftServer server;
    public boolean running;
    long tick, clock;
    final Map<UUID, Long> falling = new HashMap<>();
    boolean lastBalanceEmpty = true;
    boolean counting; int countStep; long nextCount;
    final Set<UUID> frozen = new HashSet<>();
    final Set<UUID> participants = new HashSet<>();

    // ---- Configuración (editable con /cuerdafloja config ...) ----
    public int survivors = 4;            // cuántos quedan vivos para terminar
    public double startStamina = 60;     // estamina inicial (0-100)
    public double drainMult = 1.0;       // multiplicador general de la caída (0.5 = mitad de rápido)
    public double baseDrain = 4;         // pérdida por segundo al inicio
    public double drainRamp = 0.25;      // cuánto aumenta la pérdida cada segundo
    public double windowSec = 1.7;       // segundos para pulsar al inicio
    public double minWindowSec = 0.65;   // mínimo de segundos para pulsar
    public double hitGain = 7;           // estamina base por acierto
    public double hitBonus = 9;          // extra por acertar rápido
    public double wrongPenalty = 12;     // castigo por tecla equivocada
    public double latePenalty = 14;      // castigo por tardar
    public boolean killOnFall = true;    // si el jugador que cae muere
    public double killAfterSec = 2.0;    // segundos cayendo antes de morir
    public String keys = "ASDFQWERZXCVJKL";

    public boolean setKeys(String s) {
        String k = s.toUpperCase().replaceAll("[^A-Z0-9]", "");
        k = k.chars().distinct().collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append).toString();
        if (k.length() < 2) return false;
        keys = k;
        return true;
    }

    // ---- Jugadores ----
    public boolean add(ServerPlayerEntity sp) {
        if (running || counting) return false;
        P p = new P();
        p.id = sp.getUuid(); p.name = sp.getName().getString(); p.stamina = startStamina;
        roster.put(p.id, p);
        return true;
    }

    public boolean remove(ServerPlayerEntity sp) {
        P p = roster.remove(sp.getUuid());
        if (p == null) return false;
        if (running) { sendOff(sp); if (roster.size() <= survivors) finish(); }
        return true;
    }

    public String list() {
        if (roster.isEmpty()) return "No hay jugadores en la cuerda floja.";
        return "Jugadores (" + roster.size() + "): " +
                roster.values().stream().map(p -> p.name).collect(Collectors.joining(", "));
    }

    public List<ServerPlayerEntity> online(MinecraftServer s) {
        List<ServerPlayerEntity> l = new ArrayList<>();
        for (P p : roster.values()) {
            ServerPlayerEntity sp = s.getPlayerManager().getPlayer(p.id);
            if (sp != null) l.add(sp);
        }
        return l;
    }

    // ---- Control de partida ----
    public String start(MinecraftServer s) {
        if (running || counting) return "Ya hay una partida en marcha.";
        if (roster.size() <= survivors)
            return "Necesitas más jugadores (" + roster.size() + ") que sobrevivientes (" + survivors + ").";
        server = s; counting = true; countStep = 3;
        participants.clear(); participants.addAll(roster.keySet());
        for (ServerPlayerEntity sp : online(s)) freeze(sp);
        announce(3); nextCount = clock + 20;
        return null;
    }

    void beginGame() {
        running = true; tick = 0;
        for (P p : roster.values()) { p.stamina = startStamina; prompt(p, 0); }
        broadcast("¡CUERDA FLOJA! Quedan vivos " + survivors + ". ¡Pulsa las teclas!", Formatting.GOLD);
    }

    public boolean stop() {
        if (!running && !counting) return false;
        for (P p : roster.values()) { ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id); if (sp != null) sendOff(sp); }
        running = false; counting = false; roster.clear(); Ropes.PLACED.clear(); falling.clear(); unfreezeAll();
        broadcast("Cuerda floja cancelada.", Formatting.GRAY);
        return true;
    }

    void finish() {
        String names = roster.values().stream().map(p -> p.name).collect(Collectors.joining(", "));
        for (P p : roster.values()) { ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id); if (sp != null) sendOff(sp); }
        if (names.isEmpty()) broadcast("Nadie sobrevivió.", Formatting.GRAY);
        else broadcast("🏆 Sobrevivieron: " + names, Formatting.GREEN);
        announceAll(9);
        unfreezeAll();
        running = false; roster.clear(); Ropes.PLACED.clear();
    }

    // ---- Lógica por tick ----
    public void tick(MinecraftServer s) {
        server = s; clock++;
        if (!falling.isEmpty()) {
            falling.entrySet().removeIf(e -> {
                if (clock < e.getValue()) return false;
                ServerPlayerEntity sp = s.getPlayerManager().getPlayer(e.getKey());
                if (sp != null && sp.isAlive()) sp.kill();
                return true;
            });
        }
        if (clock % 2 == 0) syncBalance();
        if (clock % 20 == 0 && !frozen.isEmpty()) {
            for (UUID id : frozen) {
                ServerPlayerEntity sp = s.getPlayerManager().getPlayer(id);
                if (sp != null) ServerPlayNetworking.send(sp, new Net.Freeze(true));
            }
        }
        if (counting && clock >= nextCount) {
            countStep--;
            if (countStep > 0) { announce(countStep); nextCount = clock + 20; }
            else { announce(0); counting = false; beginGame(); }
        }
        if (!running) return;
        tick++;
        double el = tick / 20.0;
        double rate = (baseDrain + drainRamp * el) * drainMult;

        for (P p : new ArrayList<>(roster.values())) {
            ServerPlayerEntity sp0 = s.getPlayerManager().getPlayer(p.id);
            if (sp0 == null) { p.stamina = -1000; continue; }
            if (Ropes.hasFallen(sp0)) { p.stamina = -500; continue; }
            p.stamina -= rate / 20.0;
            if (tick > p.deadline) { p.stamina -= latePenalty; prompt(p, 2); }
        }

        List<P> dead = roster.values().stream().filter(p -> p.stamina <= 0)
                .sorted(Comparator.comparingDouble(p -> p.stamina)).collect(Collectors.toList());
        for (P p : dead) {
            if (roster.size() <= survivors) { p.stamina = 1; continue; }   // se salva por poco
            eliminate(p);
        }
        if (roster.size() <= survivors) { finish(); return; }

        if (tick % 2 == 0) syncAll();
    }

    public void onKey(ServerPlayerEntity sp, int seq, int key) {
        if (!running) return;
        P p = roster.get(sp.getUuid());
        if (p == null || seq != p.seq) return;
        if (!((key >= 65 && key <= 90) || (key >= 48 && key <= 57))) return;
        if (key == p.key) {
            double frac = Math.max(0, 1 - (double) (tick - p.promptTick) / p.window);
            p.stamina = Math.min(100, p.stamina + hitGain + hitBonus * frac);
            prompt(p, 1);
        } else {
            p.stamina -= wrongPenalty;
            prompt(p, 2);
        }
    }

    // ---- Auxiliares ----
    void prompt(P p, int result) {
        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
        if (sp == null) return;
        int prev = p.key;
        do { p.key = keys.charAt(rnd.nextInt(keys.length())); } while (p.key == prev);
        double el = tick / 20.0;
        p.seq++;
        p.window = (int) (Math.max(minWindowSec, windowSec - 0.025 * el) * 20);
        p.promptTick = tick; p.deadline = tick + p.window;
        send(sp, p, result);
    }

    void send(ServerPlayerEntity sp, P p, int result) {
        float st = (float) Math.max(0, Math.min(100, p.stamina));
        ServerPlayNetworking.send(sp, new Net.State(true, p.seq, p.key, p.window, st, result));
    }

    void sendOff(ServerPlayerEntity sp) {
        ServerPlayNetworking.send(sp, new Net.State(false, 0, 0, 0, 0f, 0));
        ServerPlayNetworking.send(sp, new Net.Standings(""));
    }

    void syncAll() {
        String st = roster.values().stream().sorted(Comparator.comparingDouble(p -> p.stamina)).limit(12)
                .map(p -> p.name + ":" + (int) Math.max(0, p.stamina)).collect(Collectors.joining("|"));
        for (P p : roster.values()) {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
            if (sp == null) continue;
            send(sp, p, 0);
            ServerPlayNetworking.send(sp, new Net.Standings(st));
        }
    }

    /** El jugador pierde el equilibrio: lo empujamos de lado para que caiga de la cuerda. */
    void eliminate(P p) {
        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(p.id);
        roster.remove(p.id);
        Ropes.PLACED.remove(p.id);
        unfreeze(p.id);
        if (sp != null) {
            sendOff(sp);
            push(sp);
            if (killOnFall) falling.put(p.id, clock + (long) (killAfterSec * 20));
            else falling.put(p.id, clock + 60);   // solo para mantener la animación unos segundos
        }
        broadcast("☠ " + p.name + " ha sido eliminado de la cuerda floja. Quedan " + roster.size() + ".", Formatting.RED);
    }

    void push(ServerPlayerEntity sp) {
        Boolean ax = Ropes.alongX(sp);
        double sgn = rnd.nextBoolean() ? 1 : -1;
        double vx, vz;
        if (ax == null) { Vec3d f = sp.getRotationVector(); vx = -f.z * sgn; vz = f.x * sgn; }
        else if (ax) { vx = 0; vz = sgn; }
        else { vx = sgn; vz = 0; }
        sp.setVelocity(vx * 0.5, 0.3, vz * 0.5);
        sp.velocityModified = true;
        sp.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(sp));
    }

    /** Avisa a todos los clientes de quién está haciendo equilibrio (para animar los brazos). */
    void syncBalance() {
        if (server == null) return;
        StringBuilder sb = new StringBuilder();
        if (running) {
            for (P p : roster.values()) {
                if (sb.length() > 0) sb.append('|');
                sb.append(p.id).append(':').append((int) Math.max(0, Math.min(100, p.stamina)));
            }
        }
        for (UUID id : falling.keySet()) {
            if (sb.length() > 0) sb.append('|');
            sb.append(id).append(":0");
        }
        String st = sb.toString();
        if (st.isEmpty() && lastBalanceEmpty) return;
        lastBalanceEmpty = st.isEmpty();
        Net.Balance pkt = new Net.Balance(st);
        for (ServerPlayerEntity sp : server.getPlayerManager().getPlayerList()) ServerPlayNetworking.send(sp, pkt);
    }

    // ---- Congelar jugadores y mostrar imágenes (cuenta regresiva / fin) ----
    public void freezeAll(List<ServerPlayerEntity> ps) { for (ServerPlayerEntity sp : ps) freeze(sp); }

    void freeze(ServerPlayerEntity sp) {
        frozen.add(sp.getUuid());
        ServerPlayNetworking.send(sp, new Net.Freeze(true));
    }

    void unfreeze(UUID id) {
        if (!frozen.remove(id) || server == null) return;
        ServerPlayerEntity sp = server.getPlayerManager().getPlayer(id);
        if (sp != null) ServerPlayNetworking.send(sp, new Net.Freeze(false));
    }

    public void unfreezeAll() {
        if (server != null) {
            for (UUID id : frozen) {
                ServerPlayerEntity sp = server.getPlayerManager().getPlayer(id);
                if (sp != null) ServerPlayNetworking.send(sp, new Net.Freeze(false));
            }
        }
        frozen.clear();
    }

    void announce(int code) {
        for (ServerPlayerEntity sp : online(server)) ServerPlayNetworking.send(sp, new Net.Announce(code));
    }

    void announceAll(int code) {
        for (UUID id : participants) {
            ServerPlayerEntity sp = server.getPlayerManager().getPlayer(id);
            if (sp != null) ServerPlayNetworking.send(sp, new Net.Announce(code));
        }
    }

    void broadcast(String msg, Formatting f) {
        server.getPlayerManager().broadcast(Text.literal(msg).formatted(f), false);
    }
}
