package com.cuerdafloja;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;

/** Cuerdas físicas del mundo: rectas en X o Z, a la misma altura. Se guardan en config/cuerdafloja-ropes.txt */
public final class Ropes {
    private Ropes() {}

    public record Rope(RegistryKey<World> dim, BlockPos a, BlockPos b) {
        boolean alongX() { return a.getZ() == b.getZ(); }
        int len() { return Math.abs(b.getX() - a.getX()) + Math.abs(b.getZ() - a.getZ()) + 1; }
    }

    public static final List<Rope> LIST = new ArrayList<>();
    public static final Set<UUID> PLACED = new HashSet<>();   // jugadores puestos en la cuerda con /cuerdafloja tp

    public static String validate(BlockPos a, BlockPos b) {
        if (a.getY() != b.getY()) return "La cuerda debe estar a la misma altura (misma Y).";
        boolean dx = a.getX() != b.getX(), dz = a.getZ() != b.getZ();
        if (dx == dz) return "La cuerda debe ser recta: cambia solo X o solo Z entre los dos puntos.";
        if (Math.abs(b.getX() - a.getX()) + Math.abs(b.getZ() - a.getZ()) + 1 > 128) return "Máximo 128 bloques de largo.";
        return null;
    }

    /** Construye la cuerda con cadenas (finas, de verdad parece una cuerda). */
    public static void build(ServerWorld w, BlockPos a, BlockPos b) {
        boolean ax = a.getZ() == b.getZ();
        int n = Math.abs(b.getX() - a.getX()) + Math.abs(b.getZ() - a.getZ()) + 1;
        int sx = Integer.signum(b.getX() - a.getX()), sz = Integer.signum(b.getZ() - a.getZ());
        BlockState st = Blocks.CHAIN.getDefaultState().with(Properties.AXIS, ax ? Direction.Axis.X : Direction.Axis.Z);
        for (int i = 0; i < n; i++) w.setBlockState(a.add(sx * i, 0, sz * i), st);
    }

    /** Reparte a los jugadores por las cuerdas, separados entre sí. */
    public static int tp(MinecraftServer s, List<ServerPlayerEntity> ps) {
        int R = LIST.size(), done = 0;
        for (int r = 0; r < R; r++) {
            Rope rp = LIST.get(r);
            ServerWorld w = s.getWorld(rp.dim());
            if (w == null) continue;
            List<ServerPlayerEntity> group = new ArrayList<>();
            for (int i = r; i < ps.size(); i += R) group.add(ps.get(i));
            int sx = Integer.signum(rp.b().getX() - rp.a().getX()), sz = Integer.signum(rp.b().getZ() - rp.a().getZ());
            for (int k = 0; k < group.size(); k++) {
                int idx = (int) Math.round((k + 1.0) / (group.size() + 1.0) * (rp.len() - 1));
                BlockPos pos = rp.a().add(sx * idx, 0, sz * idx);
                VoxelShape sh = w.getBlockState(pos).getCollisionShape(w, pos);
                double top = sh.isEmpty() ? 1.0 : sh.getMax(Direction.Axis.Y);
                float yaw = rp.alongX() ? (sx > 0 ? -90f : 90f) : (sz > 0 ? 0f : 180f);
                ServerPlayerEntity p = group.get(k);
                p.teleport(w, pos.getX() + 0.5, pos.getY() + top, pos.getZ() + 0.5, yaw, 0f);
                p.setVelocity(Vec3d.ZERO);
                p.fallDistance = 0;
                PLACED.add(p.getUuid());
                done++;
            }
        }
        return done;
    }

    /** true si un jugador puesto en la cuerda ya está muy por debajo de ella. */
    public static boolean hasFallen(ServerPlayerEntity p) {
        if (LIST.isEmpty() || !PLACED.contains(p.getUuid())) return false;
        int min = Integer.MAX_VALUE;
        for (Rope r : LIST) min = Math.min(min, r.a().getY());
        return p.getY() < min - 1.0;
    }

    public static String describe(int i, Rope r) {
        return (i + 1) + ") " + r.a().getX() + " " + r.a().getY() + " " + r.a().getZ()
                + " -> " + r.b().getX() + " " + r.b().getY() + " " + r.b().getZ() + " (" + r.len() + " bloques)";
    }

    static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("cuerdafloja-ropes.txt"); }

    public static void save() {
        try {
            List<String> l = new ArrayList<>();
            for (Rope r : LIST) l.add(r.dim().getValue() + " " + r.a().getX() + " " + r.a().getY() + " " + r.a().getZ()
                    + " " + r.b().getX() + " " + r.b().getY() + " " + r.b().getZ());
            Files.write(file(), l);
        } catch (IOException e) { e.printStackTrace(); }
    }

    public static void load() {
        LIST.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            for (String s : Files.readAllLines(f)) {
                String[] t = s.trim().split(" ");
                if (t.length < 7) continue;
                LIST.add(new Rope(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(t[0])),
                        new BlockPos(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3])),
                        new BlockPos(Integer.parseInt(t[4]), Integer.parseInt(t[5]), Integer.parseInt(t[6]))));
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
