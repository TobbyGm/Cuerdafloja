package com.cuerdafloja;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.PillarBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;

public final class ModBlocks {
    private ModBlocks() {}

    public static final Block CUERDA = Registry.register(Registries.BLOCK, Identifier.of("cuerdafloja", "cuerda"),
            new RopeBlock(AbstractBlock.Settings.create().strength(0.8f).sounds(BlockSoundGroup.WOOL).nonOpaque()));
    public static final Item CUERDA_ITEM = Registry.register(Registries.ITEM, Identifier.of("cuerdafloja", "cuerda"),
            new BlockItem(CUERDA, new Item.Settings()));

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(e -> e.add(CUERDA_ITEM));
    }

    public static BlockState rope(Direction.Axis axis) {
        return CUERDA.getDefaultState().with(PillarBlock.AXIS, axis);
    }
}
